-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2016 at 07:13 PM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medical_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(2) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(99) NOT NULL,
  `admin_email` varchar(256) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `admin_status` int(11) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_status`) VALUES
(1, 'Backlog Sujon', 'sujon@yahoo.com', 'sujon', 1);

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE IF NOT EXISTS `blog` (
  `blog_id` int(6) NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(10) NOT NULL,
  `published_time` datetime NOT NULL,
  PRIMARY KEY (`blog_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=33 ;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `user_id`, `title`, `description`, `status`, `published_time`) VALUES
(17, 88, 'A drug designed to kill cells can, at lower doses, clear out the buildup that causes the feared brain diseases.', '</h2></p>\r\n<img src="../../images/parkinson.jpg"><p>\r\nThe movie “Awakenings” aside, there’s no really good treatment for the half a million Americans living with Parkinson’s disease.\r\n\r\nDopamine-replacing drugs often help control the movement disorders that are the hallmark of the disease.\r\n\r\nBut they don’t work for all patients, and they don’t bring any relief from the cognitive effects of the disease — in fact, they often make them worse.\r\n\r\nThat’s why there’s a lot of excitement about a small study using nilotinib (Tasigna) to treat Parkinson’s disease.\r\n\r\nThe drug, approved by the Food and Drug Administration (FDA) to treat cancer, suppresses tumor growth by spurring cells to do some housecleaning.\r\n\r\nIn high doses, it is a heavy-hitting chemotherapy drug that cleans the cells right out of existence.\r\n\r\nIn lower doses, it seems to cause brain cells to clear out the buildup of unhealthy proteins that interfere with normal functioning.\r\n\r\n</p>\r\n<p><h3>How It Helps with Parkinson’s</h3></p>\r\n\r\nIn Parkinson’s disease, a protein called alpha-Synuclein chokes off the cells that produce dopamine. As less and less dopamine is produced, the patient’s symptoms get worse.\r\n\r\n<p>Dr. Charbel Moussa, Ph.D., a medical researcher at the Movement Disorders Program at Georgetown University Medical Center, presented at a medical conference his first findings with human patients after eight years of research into using the drug for Parkinson’s disease.\r\n</p>\r\nAlthough just 12 patients participated in the trial, Moussa and his peers are excited because the drug seemed to reverse Parkinson’s symptoms, not just slow their progression.\r\n\r\nThe study participants had Parkinson’s disease with symptoms of dementia or Lewy Body dementia, which Moussa described as a combination of Parkinson’s and Alzheimer’s. ', '1', '2015-10-03 20:10:15'),
(32, 88, 'Wide Range of Pesticides Contribute to Dwindling Bee Populations, Study Finds', '<p>\r\n <br />\r\n &lt;p&gt;&lt;h3&gt;<br />\r\n <br />\r\n For the U.S. honeybees that pollinate one-third of all food crops, it&rsquo;s death by a thousand cuts.<br />\r\n Bees and Pesticides&lt;/p&gt;&lt;/h3&gt;<br />\r\n &lt;img src=&quot;../../images/bee.jpg&quot;&gt;&lt;p&gt;<br />\r\n There&rsquo;s been a lot of buzz about the disappearance of honeybees, but explanations for why their numbers have shrunk by more than one-third nearly every year since 2007 have been slow in coming.<br />\r\n &lt;/p&gt;<br />\r\n Bees may be annoying when they sting, but they also pollinate a third of all food crops, including almonds, strawberries, and pears. Honeybees contribute $12 billion to agriculture income each year.<br />\r\n &lt;p&gt;<br />\r\n Pesticides have emerged as one major suspect in the mystery of the missing bees. But of the many in use, only neocontinoids, nicotine-like chemicals, have been somewhat conclusively linked to bee colony collapse.<br />\r\n &lt;/p&gt;<br />\r\n A recent study published in the Journal of Economic Entomology sought to provide a more complete answer by testing a host of common pesticides to see what effect they had on honeybees.<br />\r\n <br />\r\n The work identified 26 highly toxic chemicals, including not just neocontinoids but also organophosphates, which are often used when cities spray for mosquitoes, and pyrethroids, which are the active ingredient in many household insecticides.<br />\r\n &lt;p&gt;&lt;h3&gt;The Dose Makes the Poison&lt;/h3&gt;&lt;/p&gt;<br />\r\n <br />\r\n Researchers Yu Cheng Zhu, John Adamczyk, and Jeff Gore looked at toxicity in a more nuanced way than previous studies have.<br />\r\n &lt;p&gt;<br />\r\n They considered how deadly a chemical was to bees at the average concentration used in agriculture.<br />\r\n &lt;/p&gt;<br />\r\n That turned up some new suspects, including carbaryl, a pesticide that is favored for food crops in the United States because it isn&rsquo;t concentrated in fat or secreted in milk.<br />\r\n &lt;p&gt;<br />\r\n Dennis vanEngelsdorp, Ph.D., a honeybee expert at the University of Maryland who was not involved in the study, said it offered &ldquo;an evenhanded approach that considers real-world exposures.&rdquo;<br />\r\n &lt;/p&gt;<br />\r\n The long list of chemicals analyzed &mdash; and some of the surprising findings &mdash; &ldquo;suggests we need to think broadly, beyond one pesticide class, when we consider real-world threats to honeybees,&rdquo; vanEngelsdorp said.<br />\r\n &lt;p&gt;<br />\r\n But pesticides aren&rsquo;t the only threat to honeybees, according to Jennifer Sass, Ph.D., a senior scientist at the Natural Resources Defense Council.<br />\r\n &lt;/p&gt;<br />\r\n Their numbers have been falling for several decades as agriculture has expanded its land base and ramped up the chemicals it uses. While herbicides, or weed killers, aren&rsquo;t directly toxic to bees, they eliminate their habitat.<br />\r\n <br />\r\n &ldquo;It also has a lot to do with habitat &mdash; the expansion of farmland and the increased use of pesticides and herbicides on their lawns and gardens. People didn&rsquo;t used to do that,&rdquo; Sass said.<br />\r\n &lt;p&gt;&lt;h3&gt;The Usual Suspect&lt;/h3&gt;&lt;/p&gt;<br />\r\n <br />\r\n RoundUp, Monsanto&rsquo;s controversial herbicide used primarily on genetically modified (GM) crops, is often at the heart of critiques of industrial farming. But the new study ranks RoundUp among the least toxic chemicals to bees.<br />\r\n &lt;p&gt;<br />\r\n Sass was not surprised, though. RoundUp is not designed to kill insects. It&rsquo;s designed to kill noncrop plants that bees might otherwise enjoy.<br />\r\n &lt;/p&gt;<br />\r\n &ldquo;We can have agricultural land that provides bee habitat, but it would involve letting a few weeds grow,&rdquo; Sass said.<br />\r\n &lt;p&gt;<br />\r\n The researchers pointed to another way that RoundUp may indirectly threaten bee populations.<br />\r\n &lt;/p&gt;<br />\r\n As GM crops have become more widespread, the types of pests have shifted. Insecticides that coat leaves are more effective on these pests.<br />\r\n <br />\r\n But when leaves are coated, the chance of &ldquo;foraging honeybees coming into direct contact with insecticides&rdquo; goes up, the study said.</p>\r\n', '1', '2016-04-07 07:04:43');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `category_id` int(5) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`, `description`) VALUES
(3, 'java', 'its a boring programming language'),
(4, 'c++', 'it is my fouvarite language'),
(5, 'telecommunication', 'there is no need to add this subject with cse'),
(6, 'php', 'I think this is better than all of language');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `comments_id` int(5) NOT NULL AUTO_INCREMENT,
  `blog_id` int(26) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`comments_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `comments`
--


-- --------------------------------------------------------

--
-- Table structure for table `district_info`
--

CREATE TABLE IF NOT EXISTS `district_info` (
  `district_id` int(11) NOT NULL AUTO_INCREMENT,
  `district_name` varchar(15) NOT NULL,
  `thana_name` varchar(20) NOT NULL,
  PRIMARY KEY (`district_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `district_info`
--

INSERT INTO `district_info` (`district_id`, `district_name`, `thana_name`) VALUES
(1, 'noakhali', 'Sadar'),
(2, 'Noakhali', 'begumganj');

-- --------------------------------------------------------

--
-- Table structure for table `drug`
--

CREATE TABLE IF NOT EXISTS `drug` (
  `drug_id` int(3) NOT NULL AUTO_INCREMENT,
  `drug_name` varchar(20) NOT NULL,
  `generic_name` varchar(20) NOT NULL,
  `indications` text NOT NULL,
  `dosage` text NOT NULL,
  `side_effects` text NOT NULL,
  `price` varchar(10) NOT NULL,
  PRIMARY KEY (`drug_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `drug`
--

INSERT INTO `drug` (`drug_id`, `drug_name`, `generic_name`, `indications`, `dosage`, `side_effects`, `price`) VALUES
(1, 'Napa', 'paracetamol', 'All conditions requiring relief from pain and fever such as neuritis, neuralgia, headache, ear ache, tooth ache, pain due to rheumatic disorder, cold, influenza, dysmenorrhoea, post-vaccination pain and fever of children etc. Napa suppositories are used for rapid symptomatic management of pain and fever.', 'Tablet/ Extra Tablet: Adults : 1-2 tablets 3-4 times daily; Syrup I Suspension : Adults : 4-8 Measuring spoonful 3-4 times daily; Children : 6-12 years : 2-4 measuring spoonful 3-4 times daily, 1-5 years : 1-2 Measuring spoonful 3-4 times daily, Up to 1 year : ^l^-\\ Measuring spoonful 3-4 times daily. Paediatric drops : Neonates & Children : 0-3 months : 0.5ml, 4-11 months : 1ml, 12-23 months : 1.5ml, 2-3 years : 2ml, 4-5 years : 3ml four times daily or as directed by physicians. Suppositories : Children : 1-5 years : 125-250mg, 6-12 years : 250-500mg, up to 4 times daily.', 'Side effects of paracetamol are usually mild, though haematological reactions including thrombocytopenia, leucopenia, pancytopenia, neutropenia, and agranulocytosis have been reported. Pancreatitis, skin rashes, and other allergic reactions occur occasionally.', '18 BDT'),
(2, 'seclo', 'Omeprazole', ' Seclo® capsule and tablet is indicated for gastroesophageal reflux disease including reflux esophagitis, acid reflux disease, duodenal and benign gastric ulcers, Helicobacter pylori eradication regimens in peptic ulcer disease, prophylaxis of acid aspiration, Zollinger-Ellison Syndrome (ZES) and for the treatment of NSAID-associated gastric ulcers, duodenal ulcers or gastroduodenal erosions. Seclo® IV is indicated primarily for the treatment of Zollinger-Ellison syndrome, and may also be used for the treatment of gastric ulcer, duodenal ulcer and reflux esophagitis.', ' Capsule and tablet: Omeprazole should be taken before meal.', 'Some omeprazole side effects may not need any medical attention. As your body gets used to the medicine these side effects may disappear. Your health care professional may be able to help you prevent or reduce these side effects.', '479.99 BDT'),
(3, 'alatrol', 'Cetirizine', ' Alatrol® is indicated for the relief of symptoms associated with seasonal allergic rhinitis due to allergen. Symptoms treated effectively include sneezing, rhinorrhea, pruritus, ocular pruritus, tearing and redness of the eyes. Alatrol® is indicated for the relief of symptoms associated with perennial allergic rhinitis due to allergens. Symptoms treated effectively include sneezing, rhinorrhea, post-nasal discharge, nasal pruritus, ocular pruritus and tearing. Alatrol® is indicated for the treatment of the uncomplicated skin manifestations of chronic idiopathic urticaria. It is also used in allergen induced asthma.', 'Alatrol® is administered with or without food. Adults and Children 6 years and older.', 'Somnolence,insomnia,headache,dry mouth,diarrhoea,nausea,vomiting,epistaxis', '25 BDT'),
(4, 'ace', 'paracetamol', ' All conditions requiring relief from pain and fever such as neuritis, neuralgia, headache, ear ache, tooth ache, pain due to rheumatic disorder, cold, influenza, dysmenorrhoea, post-vaccination pain and fever of children etc. Napa suppositories are used for rapid symptomatic management of pain and fever', 'Tablet/ Extra Tablet: Adults : 1-2 tablets 3-4 times daily; Syrup I Suspension : Adults : 4-8 Measuring spoonful 3-4 times daily; Children : 6-12 years : 2-4 measuring spoonful 3-4 times daily, 1-5 years : 1-2 Measuring spoonful 3-4 times daily, Up to 1 year : ^l^-\\ Measuring spoonful 3-4 times daily. Paediatric drops : Neonates & Children : 0-3 months : 0.5ml, 4-11 months : 1ml, 12-23 months : 1.5ml, 2-3 years : 2ml, 4-5 years : 3ml four times daily or as directed by physicians. Suppositories : Children : 1-5 years : 125-250mg', 'Side effects of paracetamol are usually mild, though haematological reactions including thrombocytopenia, leucopenia, pancytopenia, neutropenia, and agranulocytosis have been reported. Pancreatitis, skin rashes, and other allergic reactions occur occasionally', '25 BDT');

-- --------------------------------------------------------

--
-- Table structure for table `my_cv`
--

CREATE TABLE IF NOT EXISTS `my_cv` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `last_name` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(20) CHARACTER SET utf8 NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `city` varchar(10) CHARACTER SET utf8 NOT NULL,
  `gender` varchar(6) NOT NULL,
  `mobile` varchar(15) CHARACTER SET utf8 NOT NULL,
  `blood_group` varchar(2) NOT NULL,
  `factor` varchar(10) NOT NULL,
  `height` float NOT NULL,
  `weight` float NOT NULL,
  `activation_status` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'if status=1 user active or not',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=96 ;

--
-- Dumping data for table `my_cv`
--

INSERT INTO `my_cv` (`user_id`, `first_name`, `last_name`, `email`, `password`, `address`, `city`, `gender`, `mobile`, `blood_group`, `factor`, `height`, `weight`, `activation_status`) VALUES
(89, 'sajan', 'poddar', 'sajanpoddar', '202cb962ac59075b964b07152d234b70', 'akjfkds', '12', 'male', '12', 'B', 'positive', 5.5, 52, 1),
(90, 'sajan', 'poddar', 'saha@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'zvdsv', 'saf', 'male', 'ads', 'B', 'positive', 0, 0, 1),
(87, 'Mausumi', 'Akter', 'mau123450@gmail.com', '361228d0a65bd2355b029b2fe0aad7c6', '                                  Sonapur                                    ', 'Noakhali', 'female', '01828282828', 'B', 'positive', 155, 55, 1),
(88, 'Rafsana', 'Ferdous', 'rapsi@gmail.com', 'a042daca0082a2a90baca127352e7c27', '                                  BKH                                    ', 'chitagong', 'female', '0188877712', '0', '0', 150, 50, 1),
(91, 'Fokrul', 'sujon', 'fokrulsujon@gmail.co', '730056bfa3536c8c6f7e70e896963d61', '68/d gastroliver road,green road,dhaka', 'noakhali', 'male', '01878045545', 'B', 'positive', 162, 62, 1),
(92, 'samrat', 'khan', 'samrat@gmail.com', '91614fb63fdc19e1fc84948f37962424', 'ASH416', 'noakhali', 'male', '018855443', 'A', 'positive', 158, 60, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE IF NOT EXISTS `pharmacy` (
  `pharmacy_id` int(10) NOT NULL AUTO_INCREMENT,
  `Store_Name` varchar(30) NOT NULL,
  `district` varchar(18) NOT NULL,
  `thana` varchar(20) NOT NULL,
  `address` text NOT NULL,
  PRIMARY KEY (`pharmacy_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`pharmacy_id`, `Store_Name`, `district`, `thana`, `address`) VALUES
(1, 'Reshad pharmacy', 'noakhali', 'sadar', 'sonapur zero point,'),
(2, 'saha pharmacy', 'noakhali', 'sadar', 'maijdi,amania hotel'),
(3, 'Anowara Pharmacy', 'Noakhali', 'Begumganj', 'Chowmuhony,Noakhali'),
(4, 'Royal Pharmacy', 'noakhali', 'Begumganj', 'ChowRasta,Noakhali'),
(5, 'Anowara pharmacy', 'Noakhali', 'BegumGang', 'Golabaria,west of boropol');
